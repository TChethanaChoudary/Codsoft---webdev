document.addEventListener("DOMContentLoaded", function() {
    // Load tasks from local storage
    loadTasks();

    // Add event listener for the "Add Task" button
    document.getElementById("taskInput").addEventListener("keyup", function(event) {
        if (event.key === "Enter") {
            addTask();
        }
    });
});

function addTask() {
    // Get the task input value
    var taskInput = document.getElementById("taskInput");
    var taskText = taskInput.value.trim();

    if (taskText !== "") {
        // Create a new task element
        var taskList = document.getElementById("taskList");
        var li = document.createElement("li");
        li.innerHTML = `
            <span>${taskText}</span>
            <button onclick="deleteTask(this)">Delete</button>
        `;

        // Append the task to the task list
        taskList.appendChild(li);

        // Save tasks to local storage
        saveTasks();

        // Clear the input field
        taskInput.value = "";
    }
}

function deleteTask(button) {
    var li = button.parentElement;
    li.remove();

    // Save tasks to local storage
    saveTasks();
}

function saveTasks() {
    var taskList = document.getElementById("taskList").innerHTML;
    localStorage.setItem("tasks", taskList);
}

function loadTasks() {
    var taskList = localStorage.getItem("tasks");
    if (taskList) {
        document.getElementById("taskList").innerHTML = taskList;
    }
}