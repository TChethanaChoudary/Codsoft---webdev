let display = document.getElementById('display');
let currentInput = '';

function appendToDisplay(value) {
    currentInput += value;
    display.value = currentInput;
}

function clearDisplay() {
    currentInput = '';
    display.value = '';
}

function calculateResult() {
    try {
        // Use eval to perform the calculation
        let result = eval(currentInput);

        // Check if the result is a valid number
        if (isNaN(result) || !isFinite(result)) {
            display.value = 'Error';
        } else {
            display.value = result;
        }

        // Reset currentInput
        currentInput = '';
    } catch (error) {
        // Handle any errors that may occur during evaluation
        display.value = 'Error';
        currentInput = '';
    }
}